/**
 * LUMIÈRE Beauty & Wellness - Shopify Theme JavaScript
 */

// =============================================================================
// Utility Functions
// =============================================================================

const debounce = (fn, wait) => {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
};

const fetchConfig = (type = 'json') => {
  return {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': `application/${type}`
    }
  };
};

// =============================================================================
// Header Component
// =============================================================================

class Header {
  constructor() {
    this.header = document.querySelector('.header');
    this.lastScroll = 0;
    
    if (this.header) {
      this.init();
    }
  }

  init() {
    window.addEventListener('scroll', debounce(() => this.onScroll(), 10));
  }

  onScroll() {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
      this.header.classList.add('scrolled');
    } else {
      this.header.classList.remove('scrolled');
    }
    
    this.lastScroll = currentScroll;
  }
}

// =============================================================================
// Cart Drawer Component
// =============================================================================

class CartDrawer {
  constructor() {
    this.overlay = document.querySelector('.cart-drawer-overlay');
    this.drawer = document.querySelector('.cart-drawer');
    this.openButtons = document.querySelectorAll('[data-cart-toggle]');
    this.closeButton = document.querySelector('.cart-drawer__close');
    this.itemsContainer = document.querySelector('.cart-drawer__items');
    this.cartCount = document.querySelectorAll('[data-cart-count]');
    this.subtotal = document.querySelector('.cart-drawer__subtotal-value');
    
    if (this.overlay && this.drawer) {
      this.init();
    }
  }

  init() {
    this.openButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.open();
      });
    });

    if (this.closeButton) {
      this.closeButton.addEventListener('click', () => this.close());
    }

    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) {
        this.close();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen()) {
        this.close();
      }
    });

    // Listen for cart updates
    document.addEventListener('cart:updated', () => this.refresh());
  }

  open() {
    this.overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    this.drawer.querySelector('.cart-drawer__close').focus();
  }

  close() {
    this.overlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  isOpen() {
    return this.overlay.classList.contains('active');
  }

  async refresh() {
    try {
      const response = await fetch(`${window.routes.cart_url}.js`);
      const cart = await response.json();
      
      this.updateCartCount(cart.item_count);
      this.updateSubtotal(cart.total_price);
      this.renderItems(cart.items);
    } catch (error) {
      console.error('Error refreshing cart:', error);
    }
  }

  updateCartCount(count) {
    this.cartCount.forEach(el => {
      el.textContent = count;
      el.style.display = count > 0 ? 'flex' : 'none';
    });
  }

  updateSubtotal(total) {
    if (this.subtotal) {
      this.subtotal.textContent = this.formatMoney(total);
    }
  }

  formatMoney(cents) {
    return '$' + (cents / 100).toFixed(2);
  }

  renderItems(items) {
    if (!this.itemsContainer) return;

    if (items.length === 0) {
      this.itemsContainer.innerHTML = `
        <div class="cart-drawer__empty">
          <p>Your cart is empty</p>
          <a href="/collections/all" class="btn btn--primary btn--small mt-md">Continue Shopping</a>
        </div>
      `;
      return;
    }

    this.itemsContainer.innerHTML = items.map(item => `
      <div class="cart-item" data-key="${item.key}">
        <div class="cart-item__image">
          ${item.image ? `<img src="${item.image}" alt="${item.title}">` : ''}
        </div>
        <div class="cart-item__details">
          <h4 class="cart-item__title">${item.product_title}</h4>
          ${item.variant_title ? `<p class="cart-item__variant">${item.variant_title}</p>` : ''}
          <span class="cart-item__price">${this.formatMoney(item.final_line_price)}</span>
          <div class="cart-item__quantity">
            <button class="cart-item__qty-btn" data-action="decrease" data-key="${item.key}">−</button>
            <span>${item.quantity}</span>
            <button class="cart-item__qty-btn" data-action="increase" data-key="${item.key}">+</button>
          </div>
        </div>
        <button class="cart-item__remove" data-action="remove" data-key="${item.key}">Remove</button>
      </div>
    `).join('');

    // Add event listeners for quantity buttons
    this.itemsContainer.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', (e) => this.handleQuantityChange(e));
    });
  }

  async handleQuantityChange(e) {
    const button = e.currentTarget;
    const action = button.dataset.action;
    const key = button.dataset.key;
    
    const item = this.itemsContainer.querySelector(`[data-key="${key}"]`);
    const quantityEl = item.querySelector('.cart-item__quantity span');
    let quantity = parseInt(quantityEl.textContent);

    if (action === 'increase') {
      quantity++;
    } else if (action === 'decrease') {
      quantity = Math.max(0, quantity - 1);
    } else if (action === 'remove') {
      quantity = 0;
    }

    await this.updateQuantity(key, quantity);
  }

  async updateQuantity(key, quantity) {
    try {
      const response = await fetch(window.routes.cart_change_url + '.js', {
        ...fetchConfig(),
        body: JSON.stringify({ id: key, quantity })
      });
      
      const cart = await response.json();
      
      this.updateCartCount(cart.item_count);
      this.updateSubtotal(cart.total_price);
      this.renderItems(cart.items);
      
      document.dispatchEvent(new CustomEvent('cart:updated', { detail: cart }));
    } catch (error) {
      console.error('Error updating cart:', error);
    }
  }
}

// =============================================================================
// Quick Add Component
// =============================================================================

class QuickAdd {
  constructor() {
    this.buttons = document.querySelectorAll('[data-quick-add]');
    
    if (this.buttons.length) {
      this.init();
    }
  }

  init() {
    this.buttons.forEach(btn => {
      btn.addEventListener('click', (e) => this.handleClick(e));
    });
  }

  async handleClick(e) {
    e.preventDefault();
    e.stopPropagation();
    
    const button = e.currentTarget;
    const variantId = button.dataset.variantId;
    const originalText = button.textContent;
    
    button.disabled = true;
    button.textContent = 'Adding...';
    
    try {
      const response = await fetch(window.routes.cart_add_url + '.js', {
        ...fetchConfig(),
        body: JSON.stringify({
          items: [{ id: variantId, quantity: 1 }]
        })
      });
      
      if (!response.ok) throw new Error('Failed to add to cart');
      
      button.textContent = 'Added!';
      button.style.background = 'var(--color-sage)';
      
      // Refresh cart drawer
      document.dispatchEvent(new CustomEvent('cart:updated'));
      
      // Open cart drawer
      const cartDrawer = document.querySelector('.cart-drawer-overlay');
      if (cartDrawer) {
        cartDrawer.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
      
      setTimeout(() => {
        button.textContent = originalText;
        button.style.background = '';
        button.disabled = false;
      }, 1500);
      
    } catch (error) {
      console.error('Error adding to cart:', error);
      button.textContent = 'Error';
      
      setTimeout(() => {
        button.textContent = originalText;
        button.disabled = false;
      }, 1500);
    }
  }
}

// =============================================================================
// Product Form Component
// =============================================================================

class ProductForm {
  constructor(container) {
    this.container = container;
    this.form = container.querySelector('form');
    this.submitButton = container.querySelector('[data-add-to-cart]');
    this.quantityInput = container.querySelector('[data-quantity-input]');
    this.quantityButtons = container.querySelectorAll('[data-quantity-btn]');
    this.optionInputs = container.querySelectorAll('[data-option-input]');
    this.variantIdInput = container.querySelector('[name="id"]');
    this.priceEl = container.querySelector('[data-product-price]');
    this.comparePriceEl = container.querySelector('[data-compare-price]');
    
    this.productData = JSON.parse(
      container.querySelector('[data-product-json]')?.textContent || '{}'
    );
    
    if (this.form) {
      this.init();
    }
  }

  init() {
    this.form.addEventListener('submit', (e) => this.onSubmit(e));
    
    this.quantityButtons.forEach(btn => {
      btn.addEventListener('click', () => this.updateQuantity(btn.dataset.action));
    });
    
    this.optionInputs.forEach(input => {
      input.addEventListener('change', () => this.onVariantChange());
    });
  }

  updateQuantity(action) {
    let quantity = parseInt(this.quantityInput.value) || 1;
    
    if (action === 'increase') {
      quantity++;
    } else if (action === 'decrease') {
      quantity = Math.max(1, quantity - 1);
    }
    
    this.quantityInput.value = quantity;
  }

  onVariantChange() {
    const selectedOptions = [];
    this.optionInputs.forEach(input => {
      if (input.checked || input.selected) {
        selectedOptions.push(input.value);
      }
    });
    
    const variant = this.productData.variants?.find(v => {
      return v.options.every((opt, i) => opt === selectedOptions[i]);
    });
    
    if (variant) {
      this.variantIdInput.value = variant.id;
      this.updatePrice(variant);
      this.updateAvailability(variant);
      
      // Update URL
      const url = new URL(window.location);
      url.searchParams.set('variant', variant.id);
      window.history.replaceState({}, '', url);
    }
  }

  updatePrice(variant) {
    if (this.priceEl) {
      this.priceEl.textContent = this.formatMoney(variant.price);
    }
    
    if (this.comparePriceEl) {
      if (variant.compare_at_price > variant.price) {
        this.comparePriceEl.textContent = this.formatMoney(variant.compare_at_price);
        this.comparePriceEl.style.display = '';
      } else {
        this.comparePriceEl.style.display = 'none';
      }
    }
  }

  updateAvailability(variant) {
    if (variant.available) {
      this.submitButton.disabled = false;
      this.submitButton.textContent = 'Add to Cart';
    } else {
      this.submitButton.disabled = true;
      this.submitButton.textContent = 'Sold Out';
    }
  }

  formatMoney(cents) {
    return '$' + (cents / 100).toFixed(2);
  }

  async onSubmit(e) {
    e.preventDefault();
    
    const originalText = this.submitButton.textContent;
    this.submitButton.disabled = true;
    this.submitButton.textContent = 'Adding...';
    
    try {
      const formData = new FormData(this.form);
      const response = await fetch(window.routes.cart_add_url + '.js', {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) throw new Error('Failed to add to cart');
      
      this.submitButton.textContent = 'Added!';
      
      // Refresh cart
      document.dispatchEvent(new CustomEvent('cart:updated'));
      
      // Open cart drawer
      const cartDrawer = document.querySelector('.cart-drawer-overlay');
      if (cartDrawer) {
        cartDrawer.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
      
      setTimeout(() => {
        this.submitButton.textContent = originalText;
        this.submitButton.disabled = false;
      }, 1500);
      
    } catch (error) {
      console.error('Error adding to cart:', error);
      this.submitButton.textContent = 'Error - Try Again';
      
      setTimeout(() => {
        this.submitButton.textContent = originalText;
        this.submitButton.disabled = false;
      }, 2000);
    }
  }
}

// =============================================================================
// Newsletter Form Component
// =============================================================================

class NewsletterForm {
  constructor() {
    this.forms = document.querySelectorAll('.newsletter__form');
    
    if (this.forms.length) {
      this.init();
    }
  }

  init() {
    this.forms.forEach(form => {
      form.addEventListener('submit', (e) => this.onSubmit(e));
    });
  }

  onSubmit(e) {
    e.preventDefault();
    
    const form = e.currentTarget;
    const input = form.querySelector('.newsletter__input');
    const button = form.querySelector('.newsletter__btn');
    const originalText = button.textContent;
    
    if (!input.value) return;
    
    // In a real implementation, this would submit to Shopify's customer API
    // or a third-party email service
    
    button.textContent = 'Subscribed!';
    button.style.background = 'var(--color-sage-dark)';
    input.value = '';
    
    setTimeout(() => {
      button.textContent = originalText;
      button.style.background = '';
    }, 2000);
  }
}

// =============================================================================
// Scroll Animations
// =============================================================================

class ScrollAnimations {
  constructor() {
    this.elements = document.querySelectorAll('[data-animate]');
    
    if (this.elements.length && 'IntersectionObserver' in window) {
      this.init();
    }
  }

  init() {
    const options = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    this.observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animated');
          this.observer.unobserve(entry.target);
        }
      });
    }, options);

    this.elements.forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(30px)';
      el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      this.observer.observe(el);
    });
  }
}

// Add CSS for animated state
const style = document.createElement('style');
style.textContent = `
  [data-animate].animated {
    opacity: 1 !important;
    transform: translateY(0) !important;
  }
`;
document.head.appendChild(style);

// =============================================================================
// Mobile Menu
// =============================================================================

class MobileMenu {
  constructor() {
    this.toggle = document.querySelector('.header__menu-toggle');
    this.menu = document.querySelector('.mobile-menu');
    this.overlay = document.querySelector('.mobile-menu-overlay');
    this.closeBtn = document.querySelector('.mobile-menu__close');
    
    if (this.toggle && this.menu) {
      this.init();
    }
  }

  init() {
    this.toggle.addEventListener('click', () => this.open());
    
    if (this.closeBtn) {
      this.closeBtn.addEventListener('click', () => this.close());
    }
    
    if (this.overlay) {
      this.overlay.addEventListener('click', () => this.close());
    }
    
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen()) {
        this.close();
      }
    });
  }

  open() {
    this.menu.classList.add('active');
    if (this.overlay) this.overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  close() {
    this.menu.classList.remove('active');
    if (this.overlay) this.overlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  isOpen() {
    return this.menu.classList.contains('active');
  }
}

// =============================================================================
// Product Gallery
// =============================================================================

class ProductGallery {
  constructor(container) {
    this.container = container;
    this.mainImage = container.querySelector('.product__main-image img');
    this.thumbnails = container.querySelectorAll('.product__thumbnail');
    
    if (this.mainImage && this.thumbnails.length) {
      this.init();
    }
  }

  init() {
    this.thumbnails.forEach(thumb => {
      thumb.addEventListener('click', () => this.switchImage(thumb));
    });
  }

  switchImage(thumbnail) {
    const newSrc = thumbnail.dataset.src || thumbnail.querySelector('img').src;
    
    this.mainImage.src = newSrc;
    
    this.thumbnails.forEach(t => t.classList.remove('active'));
    thumbnail.classList.add('active');
  }
}

// =============================================================================
// Initialize All Components
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
  // Global components
  new Header();
  new CartDrawer();
  new QuickAdd();
  new NewsletterForm();
  new ScrollAnimations();
  new MobileMenu();
  
  // Product page components
  document.querySelectorAll('[data-product-form]').forEach(container => {
    new ProductForm(container);
  });
  
  document.querySelectorAll('[data-product-gallery]').forEach(container => {
    new ProductGallery(container);
  });
  
  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
});

// =============================================================================
// Shopify Section Events (for Theme Editor)
// =============================================================================

document.addEventListener('shopify:section:load', (e) => {
  const section = e.target;
  
  // Re-initialize components in the loaded section
  new QuickAdd();
  new ScrollAnimations();
  
  section.querySelectorAll('[data-product-form]').forEach(container => {
    new ProductForm(container);
  });
  
  section.querySelectorAll('[data-product-gallery]').forEach(container => {
    new ProductGallery(container);
  });
});

document.addEventListener('shopify:section:unload', (e) => {
  // Cleanup if needed
});

document.addEventListener('shopify:section:select', (e) => {
  // Handle section selection in theme editor
});

document.addEventListener('shopify:section:deselect', (e) => {
  // Handle section deselection in theme editor
});
